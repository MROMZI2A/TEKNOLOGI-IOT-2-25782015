const int buttonPin = 4; // Pin D4 (GPIO 4)
const int ledPin = 5;    // Pin D5 (GPIO 5)

bool ledState = LOW;        // Status LED saat ini
bool lastButtonState = LOW; // Status tombol sebelumnya

void setup() {
  Serial.begin(115200);
  pinMode(buttonPin, INPUT);
  pinMode(ledPin, OUTPUT);
  digitalWrite(ledPin, ledState); // LED mati saat awal
}

void loop() {
  bool currentButtonState = digitalRead(buttonPin);

  // Deteksi saat tombol ditekan (Rising Edge)
  if (currentButtonState == HIGH && lastButtonState == LOW) {
    ledState = !ledState;          // Balik status LED (ON/OFF)
    digitalWrite(ledPin, ledState);

    // Cetak status ke Serial Monitor
    if (ledState == HIGH) {
      Serial.println("LED Menyala (ON)");
    } else {
      Serial.println("LED Mati (OFF)");
    }

    delay(200); // Debounce delay
  }

  lastButtonState = currentButtonState;
}